<?php 

	function get_latitude_and_logitude_by_order($order_id, $deli_id =""){
		$curl = curl_init();
		curl_setopt($curl, CURLOPT_URL, 'http://ip-api.com/json');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
		$data = curl_exec($curl);
		$data = json_decode($data);
		if ($data->status == "success") {
			if (isset($data->lat) && isset($data->lon)) {
				$db = \Config\Database::connect();
				$data = [
					'order_id'            => $order_id,
					'locationLatitude'    => $data->lat,
					'locationLongitude'   => $data->lon,
					'delivery_boy_id'     => $deli_id,
					'user_id'             => '1'
				];
				$builder = $db->table('track_order')
							->insert($data);
				if ($db->affectedRows() == 1) {
					return true;
				}else{
					return false;
				}				
			}
		}
	}

	function get_rec_by_order_id($tablename, $order_id){
		$args=[
			'order_id'  => $order_id
		];
		$db = \Config\Database::connect();
		$builder = $db->table($tablename)
					->select('*')
					->where($args)
					->get();
		if (count($builder->getResultArray())>0) {
			return $builder->getResult();
		}else{
			return false;
		}				
	}

	function get_Delivery_boy_rec($tablename, $id){
		$args=[
			'id'  => $order_id
		];
		$db = \Config\Database::connect();
		$builder = $db->table($tablename)
					->select('*')
					->where($args)
					->get();
		if (count($builder->getResultArray())>0) {
			return $builder->getResult();
		}else{
			return false;
		}				
	}

	function get_order_location($order_id){
		$db = \Config\Database::connect();
		$builder = $db->table('track_order');
		$builder->select('*');
		$result = $builder->where('order_id', $order_id)
                  ->get();
		if (count($result->getResultArray())> 0) {
			return $result->getResultArray();
		}else{
			return false;
		}
	}


?>