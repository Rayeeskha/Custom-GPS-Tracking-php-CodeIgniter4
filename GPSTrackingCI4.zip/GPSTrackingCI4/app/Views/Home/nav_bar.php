<!-----Nav Bar Section ----->
 <nav>
    <div class="nav-wrapper">
      <a href="#" class="brand-logo">Logo</a>
      <ul id="nav-mobile" class="right hide-on-med-and-down">
      	<li>
	  		<h6 style="font-size: 14px;color: white;text-align: center;line-height: 18px; font-weight: 500;margin-top: 15px;"><a href="<?= base_url('Home/my_carts'); ?>" style="color: white;" target="_blank">
      			<span class="fa fa-shopping-cart"></span>&nbsp;Shopping Cart <br/>
				<span id="total_products">0 </span>&nbsp;Items - <span class="fa fa-rupee-sign">&nbsp;
				<span id="total_amount">0</span>
				</span></a>
			</h6>
		</li>
		<li><a href="<?= base_url('Home/track_order'); ?>">Track Order</a></li>
       
      </ul>
    </div>
  </nav>	
<!-----Nav Bar Section ----->


<!------Php Sucess and Message Section Start ---->

 <!---Php Meassge Show --->
    <div style="margin-left: 20px;margin-right: 10px">
      <?php  if(session()->getTempdata('success')): ?>
            <div class="card">
              <div class="card-content" style="margin-left: 20px;margin-right: 20;padding: 10px; background: green;color: white;font-weight: 500">
                <span class="fa fa-check"></span>&nbsp;&nbsp;<?= session()->getTempdata('success'); ?>
              </div>
            </div>
          <?php endif; ?>
          <?php  if(session()->getTempdata('error')): ?>
            <div class="card">
              <div class="card-content" style="margin-left: 10px;margin-right: 10;padding: 10px; background: red;color: white;font-weight: 500">
                <span class="fa fa-times"></span>&nbsp;&nbsp;<?= session()->getTempdata('error'); ?>
              </div>
            </div>
    <?php endif; ?>
    </div>
    <!---Php Meassge Show --->

<!------Php Sucess and Message Section End ---->