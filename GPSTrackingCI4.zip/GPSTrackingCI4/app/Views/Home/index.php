<!DOCTYPE html>
<html>
<head>
	<title>Home Page</title>
	<?= view('Home/custom_file'); ?>
	
	<style type="text/css">
		h6{font-weight: 500;font-size: 14px;}
	</style>
</head>
<body>
<!--------Nav Bar Section Inlcude ----->
<?= view('Home/nav_bar'); ?>	
<!--------Nav Bar Section Inlcude ----->	
<div style="margin-left: 10px;margin-right: 10px;padding: 10px;margin-top: 30px">
	<div class="row">
		<?php if($products):
		count($products);
		foreach($products as $pro): ?>
			<div class="col l3 m12 s12">
				<div class="card">
					<div class="card-image"> 
						<img src="<?= base_url('public/images/1568143107638.jpeg'); ?>">
					</div>
					<div class="card-content">
						
						<center>
							<h6><?= $pro->product_name; ?></h6>
							<h6><span class="fa fa-inr"></span>Rs <?= $pro->rate; ?></h6>
							<a href="#!" class="btn btn-waves-effect waves-light" style="background: black" onclick="add_to_cart(<?= $pro->id ?>);">Purchse now</a>
						</center>
					</div>
				</div>
			</div>
		<?php endforeach; else: ?>
			<h6 style="color: red">Products Not Found</h6>
		<?php endif; ?>
		
	</div>
</div>
	

</body>
</html>

<?= view('Home/custm_js'); ?>


