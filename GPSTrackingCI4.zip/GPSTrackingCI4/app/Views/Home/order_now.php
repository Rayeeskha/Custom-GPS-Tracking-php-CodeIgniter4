<!DOCTYPE html>
<html>
<head>
	<title>Order Now</title>
	<?= view('Home/custom_file'); ?>
	<style type="text/css">
		td{font-weight: 500;font-size: 14px;}
		#input_box{width:100%;border: 1px solid silver;height:35px;border-radius: 3px;}

	</style>
</head>
<body>
<!--------Nav Bar Section Inlcude ----->
<?= view('Home/nav_bar'); ?>	
<!--------Nav Bar Section Inlcude ----->
	<div style="margin-right: 10px;margin-left: 10px">
		<div class="card">
			<div class="card-title" style="border-bottom: 1px solid silver;padding: 10px;;background: black;color: white">
				<h6>Checkout</h6>
			</div>
			<div class="card-content">
				<div class="row">
					
					<div class="col l6 m12 s12">
						<table class="table">
							<tr>
								<th>Product Name</th>
								<th>Qty</th>
								<th>Rate</th>
							</tr>
							<?php if($my_carts):
								count($my_carts);
								$total_amount = 0;
								foreach($my_carts as $carts):
									$total_amount += $carts->rate * $carts->qty;
								 ?>
							<tr>
								<td>
									<?= $carts->product_name; ?>
								</td>
								<td>
									<?= $carts->qty; ?>
								</td>
								<td>
									<?= number_format($carts->rate); ?>
								</td>
							</tr>
							<?php  endforeach; ?>
								<tr>
									<td>Final Price </td><td></td>
									<td><span class="fa fa-inr">&nbsp;<?= number_format($total_amount); ?></span></td>
								</tr>
							 <?php  else: ?>
								<h6 style="color: red;">Product Not Found</h6>
							<?php endif; ?>
						</table>
					</div>
					
					<div class="col l6 m12 s12">
						<?= form_open('Home/complete_purchase'); ?>
							<h6>Name</h6>
							<input type="text" name="cus_name" id="input_box" placeholder="Enter Your Name" required="">
							<h6>Mobile Number</h6>
							<input type="number" name="mobile" id="input_box" placeholder="Enter Mobile Number" required="">
							<h6>PINCODE</h6>
							<input type="text" name="pincode" id="input_box" placeholder="pincode" required="">
							<h6>Address</h6>
							<textarea  name="address" required=""> </textarea>
							<center>
								<button type="submit" class="btn btn-waves-effect waves-light" style="background: green">Purchase Now</button>
							</center>
						<?php form_close(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>

</body>
</html>
<?= view('Home/custm_js'); ?>

<script type="text/javascript">
