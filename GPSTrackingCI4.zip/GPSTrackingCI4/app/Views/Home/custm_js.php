<script type="text/javascript">
	function add_to_cart(product_id){
		$.ajax({
			type:'ajax',
			method:'GET',
			url:'<?= site_url('Home/add_to_cart/'); ?>'+product_id,
			success:function(data){
				if (data == "1") {
					M.toast({html:'Product Successfully Add in Your Cart..'});
					calculate_carts_product();
				}else{
					M.toast({html:'Product Not Added'});
				}
			},
			error:function(){
				alert('Error! Technical Issue Contact with Administrator');
			}

		});
	}

	    //Calculate Carts Product Script
    calculate_carts_product(); 
    function calculate_carts_product(){
        $.ajax({
            type:'ajax',
            method:'GET',
            url:'<?= base_url('Home/calculate_carts_products/'); ?>',
          
            success:function(data){
                var json_data = JSON.parse(data);
                $('#total_products').html(json_data.total_products);
                $('#total_amount').html(json_data.total_amount);
                 // location.reload();
            },
            error:function(){
                // alert('Error! Technical Issue Contact with Administrator');
            }
        });
    }
    //Calculate Carts Product Script
</script>