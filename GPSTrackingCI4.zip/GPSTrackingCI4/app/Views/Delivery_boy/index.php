<!DOCTYPE html>
<html>
<head>
	<title>Delivery Boy Login</title>
	<?= view('Home/custom_file'); ?>
	<style type="text/css">
		body{background: pink}
		#input_box{width:100%;border: 1px solid silver;height:35px;border-radius: 3px;}
	</style>
</head>
<body>
	<div style="margin-right: 10px;margin-left: 10px;margin-top: 10%">
		<div class="row">
			<div class="col l4 m12 s12"></div>
			<div class="col l4 m12 s12">
				<div class="card">
					<div class="card-content" style="padding: 10px;border-bottom: 1px solid silver">
						<h6 style="text-align: center;"><span class="fa fa-user" style="color: orange"></span>&nbsp;Delivery Boy Login</h6></div>
					<div class="card-content">
						<?php if(isset($error)): ?>
							<h6 style="color: red;"><?= $error; ?></h6>
					<?php endif; ?>
						<?= form_open('Delivery_boy/login'); ?>
						<h6>Email</h6>
						<input type="email" name="email" id="input_box" placeholder="Enter Email">
						<h6>Password</h6>
						<input type="password" name="password" id="input_box" placeholder="XXXXX">
						<button type="submit" class="btn btn-waves-effect waves-light" style="background: orange">Login Your Account</button>
						<?= form_close(); ?>
					</div>
				</div>
			</div>
			<div class="col l4 m12 s12"></div>
		</div>
	</div>

<?= view('Home/custm_js'); ?>
</body>
</html>