<!DOCTYPE html>
<html>
<head>
	<title>Delivery Boy Order Details</title>
	<?= view('Home/custom_file'); ?>
	<style type="text/css">
		h6{font-weight: 500;font-size: 13px}
	</style>
</head>
<body>
	<div style="margin-right: 10px;margin-left: 10px;margin-top: 5%">



 <!---Php Meassge Show --->
    <div style="margin-left: 20px;margin-right: 10px">
      <?php  if(session()->getTempdata('success')): ?>
            <div class="card">
              <div class="card-content" style="margin-left: 20px;margin-right: 20;padding: 10px; background: green;color: white;font-weight: 500">
                <span class="fa fa-check"></span>&nbsp;&nbsp;<?= session()->getTempdata('success'); ?>
              </div>
            </div>
          <?php endif; ?>
          <?php  if(session()->getTempdata('error')): ?>
            <div class="card">
              <div class="card-content" style="margin-left: 10px;margin-right: 10;padding: 10px; background: red;color: white;font-weight: 500">
                <span class="fa fa-times"></span>&nbsp;&nbsp;<?= session()->getTempdata('error'); ?>
              </div>
            </div>
    <?php endif; ?>
    </div>
    <!---Php Meassge Show --->

<!------Php Sucess and Message Section End ---->



		<div class="card">
			<div class="card-content" style="background: black;padding: 10px;border-bottom: 1px solid silver">
				<h6 style="color: white">Order Details
					<a href="<?= base_url('Delivery_boy/track_user/'.$order_details[0]->order_id); ?>" style="color: white;border:1px solid silver;padding: 5px" class="right">Track Order</a>
				</h6>

			</div>
			<div class="card-content">
				<div class="row">
					<div class="col l6 m12 s12">
						<h6>Customer Name : <?= $order_details[0]->cus_name; ?> </h6>
						<h6>Mobile Name : <a href="tel:<?= $order_details[0]->mobile; ?> "><?= $order_details[0]->mobile; ?> </a></h6>


					</div>
					<div class="col l6 m12 s12">
						<h6>Order Date: <span style="color: orange">&nbsp;<?=  date('D M Y', strtotime($order_details[0]->order_date)) ?></span></h6>
						<h6>Order Status : <span style="color: green;">&nbsp;<?= $order_details[0]->order_status; ?></span></h6>
					</div>
				</div>
				<table class="table">
					<tr>
						<th>Order Id</th>
						<th>Product Name</th>
						<th>QTY</th>
						<th>Price</th>
						<th>Action</th>
					</tr>
					<?php
						$pro_details = get_rec_by_order_id('ord_pro_details', $order_details[0]->order_id);
						if($pro_details):
						foreach($pro_details as $pro):
					?>
					<tr>
						<td>
							<?= $pro->order_id; ?>
						</td>
						<td>
							<?= $pro->product_name; ?>
						</td>
						<td>
							<?= $pro->qty ?>
						</td>
						<td>
							<?= $pro->rate; ?>
						</td>
						<td>
							<a href="<?= base_url('Delivery_boy/change_order_status/'.$order_details[0]->order_id.'/Accept') ?>" class="btn btn-waves-effect waves-light" style="background: blue;">Accept</a>
						</td>
					</tr>
				<?php endforeach; else: ?>
				<h6 style="color: red;">Product Not Found</h6>
			<?php endif; ?>
									
				</table>
			</div>
		</div>
	</div>


<?= view('Home/custm_js'); ?>
</body>
</html>