<?php
namespace App\models;
use CodeIgniter\Model;

Class Main_model extends Model{

	public function fetch_rec_by_args($tablename, $args,$limit){
		$builder = $this->db->table($tablename)
					->select('*')
					->where($args)
					->orderBy('id', 'DESC')
					->limit($limit)
					->get();
		if (count($builder->getResultArray())>0) {
			return $builder->getResult();
		}else{
			return false;
		}				
	}

	public function fetch_rec_by_status($tablename, $args){
		$builder = $this->db->table($tablename)
					->select('*')
					->where($args)
					->get();
		if (count($builder->getResultArray())>0) {
			return $builder->getResult();
		}else{
			return false;
		}				
	}

	public function update_rec_by_args($tablename, $args, $data){
		$builder = $this->db->table($tablename)
					->where($args)
					->update($data);
		if ($this->db->affectedRows() == 1) {
			return true;
		}else{
			return false;
		}
	}

	public function Insertdata($tablename, $data){
		$builder = $this->db->table($tablename)
					->insert($data);
		if ($this->db->affectedRows() == 1) {
			return true;
		}else{
			return false;
		}				
	}

	public function delete_rec_by_args($tablename, $args){
		$builder = $this->db->table($tablename)
					->where($args)
					->delete();
		if ($this->db->affectedRows() == 1) {
			return true;
		}else{
			return false;
		}				
	}






}



 ?>