<?php

namespace App\Controllers;
use \App\Models\Main_model;

class Home extends BaseController
{	
	public $mainmodel;
	public $session;
	public function __construct(){
		helper('Custom_helper');
		$this->mainmodel = new Main_model();
		$this->session   = session();
	}
	public function index()
	{	
		$args = [
			'status'  => '0'
		];
		$data['products'] = $this->mainmodel->fetch_rec_by_args('products', $args,4);
		return view('Home/index', $data);
	}

	public function add_to_Cart($id){
		//Set Product Session 
		if ($this->session->get('session_id') == "") {
			$user_session_id  = [
				'session_id'   => rand(9999999,999999)
			];
			$this->session->set($user_session_id);
		}
		//Check Product is Added in cart then update pro quantity

		$args = [
			'id'  => $id
		];	
		$get_pro = $this->mainmodel->fetch_rec_by_status('products', $args);

		$args = [
			'pro_id'     => $id,
			'session_id'  => $this->session->get('session_id')
		];
		$check_prod = $this->mainmodel->fetch_rec_by_status('cart_products', $args);

		if ($check_prod) {
			count($check_prod);
			$old_qty = $check_prod[0]->qty;
			$new_qty = $old_qty + 1;
			$args = [
				'pro_id'   => $check_prod[0]->pro_id
			];
			$data = [
				'qty'  => $new_qty
			];
			$result = $this->mainmodel->update_rec_by_args('cart_products', $args, $data);
			if ($result) {
				echo "1";
			}else{
				echo "0";
			}
		}else{
			$data = [
				'pro_id'       => $get_pro[0]->id,
				'product_name' => $get_pro[0]->product_name,
				'rate'         => $get_pro[0]->rate,
				'session_id'   => $this->session->get('session_id'),
				'qty'          => '1',
			];
			$result = $this->mainmodel->Insertdata('cart_products',$data);
			if ($result == true) {
				# code...
				echo "1";
			}else{
				echo "0";
			}
		}
	}

	public function calculate_carts_products(){
		$args = [
			'session_id'  => $this->session->get('session_id')
		];
		$product = $this->mainmodel->fetch_rec_by_status('cart_products', $args);
		$calulate_amt =  0;
		if ($product) {
			count($product);
			foreach($product as $pro){
				$calulate_amt += $pro->qty * $pro->rate;
			}
		}else{
			$calulate_amt =0;
		}
		$data   = [
			'total_products'   => count($product),
			'total_amount'     => ($calulate_amt > 0) ? number_format($calulate_amt) : '0'
		];
		echo json_encode($data);
	}

	public function my_carts(){
		if (session()->get('session_id') == "") {
			return  redirect()->to(base_url().'/Home/index');
		}else{
			$args =  [
				'session_id'  => $this->session->get('session_id')
			];
			$data['my_carts'] = $this->mainmodel->fetch_rec_by_status('cart_products', $args);
			return view('Home/order_now', $data);
		}
	}

	public function complete_purchase(){
		$order_id = $this->session->get('session_id');
		$args = [
			'session_id'  => $order_id
		];
		$products = $this->mainmodel->fetch_rec_by_status('cart_products', $args);
		$data = [
			'cus_name'     => $this->request->getVar('cus_name'),
			'mobile'        => $this->request->getVar('mobile'),
			'address'      => $this->request->getVar('address'),
			'pincode'      => $this->request->getVar('pincode'),
			'order_id'     => $order_id,
			'user_id'      =>'1',
			'order_date'   => date('Y-m-d h:i:s'),
			'order_status' => 'Pending',
		];
		$status = $this->mainmodel->Insertdata('order_details', $data);
		if ($status == true) {
			if ($products) {
				count($products);
				foreach($products as $pro){
					$data = [
						'order_id'     => $order_id,
						'pro_id'       => $pro->pro_id,
						'qty'          => $pro->qty,
						'rate'         => $pro->rate,
						'product_name' => $pro->product_name
					];
					$this->mainmodel->Insertdata('ord_pro_details', $data);
				}
			}
			get_latitude_and_logitude_by_order($order_id);
			$args = [
				'session_id'  => $this->session->get('session_id')
			];
			$this->mainmodel->delete_rec_by_args('cart_products', $args);
			if (session()->has('session_id')) {
				session()->remove('session_id');
			}
			$this->session->setTempdata('success', 'Congratulation !Your Product Purchse ', 3);
		}else{
			$this->session->setTempdata('error', 'Sorry ! Unable to purchase Products', 3);
		}
		return redirect()->to(base_url().'/Home/index');
	}

	public function track_order(){
		$args = [
			'user_id'  => '1'
		];
		$check = $this->mainmodel->fetch_rec_by_status('order_details', $args);
		if (!$check) {
			return redirect()->to(base_url().'/Home/index');
		}else{
			$data['map_data'] = get_order_location($check[0]->order_id);
			return view('Home/track_order', $data);
		}
	}


}
