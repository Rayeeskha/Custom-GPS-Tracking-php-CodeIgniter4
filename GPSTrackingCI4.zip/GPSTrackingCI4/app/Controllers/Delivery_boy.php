<?php

namespace App\Controllers;
use \App\Models\Main_model;

class Delivery_boy extends BaseController
{
	public $mainmodel;
	public $session;
	public function __construct(){
		helper('Custom_helper');
		$this->mainmodel = new Main_model();
		$this->session   = session();
	}

	public function index(){
		return view('Delivery_boy/index');
	}

	public function login(){
		$args = [
			'email'     => $this->request->getVar('email'),
			'password'  => md5($this->request->getVar('password'))
		];
		$userdata = $this->mainmodel->fetch_rec_by_status('deliboy_login', $args);
		// var_dump($userdata);
		// die();
		if ($userdata == true) {
			$set_deliboysesson = [
				'DELIBOY_ID'      => $userdata[0]->id,
				'DELIBOY_NAME'    => $userdata[0]->name,
				'DELIBOY_EMAIL'   => $userdata[0]->email,
				'DELIBOY_PINCODE' => $userdata[0]->pincode,
				'login_deliboy'   => TRUE
			];
			$this->session->set($set_deliboysesson);
			return redirect()->to(base_url().'/Delivery_boy/dashboard');
		}else{
			$data['error']  = 'Username & Password don Not Matched ! Please Enter Valid Username & Password';
		}
		return view('Delivery_boy/index', $data);
	}

	public function dashboard(){
		if (!(session()->has('login_deliboy'))) {
			return redirect()->to(base_url()."/Delivery_boy/index");
		}else{
			$pincode =  $this->session->get('DELIBOY_PINCODE');
			$args =  [
				'pincode'  => $pincode
			];
			$data['order_details'] = $this->mainmodel->fetch_rec_by_status('order_details', $args);
			return view('Delivery_boy/dashboard', $data);
		}
	}

	public function change_order_status($order_id, $status){
		$args =  [
			'order_id'  => $order_id
		];
		$data = [
			'order_status'  => $status
		];
		$status = $this->mainmodel->update_rec_by_args('order_details', $args, $data);
		if ($status) {
			$deliboy_id = $this->session->get('DELIBOY_ID');
			get_latitude_and_logitude_by_order($order_id, $deliboy_id);
			$this->session->setTempdata('success', 'Congratulation !Order Accepted Successfuly', 3);
		}else{
			$this->session->setTempdata('error','Failed ! Unable to Accepted',2);
		}
		return redirect()->to(base_url().'/Delivery_boy/dashboard');
	}

	public function track_user($order_id){
		$data['map_data'] = get_order_location($order_id);
		if ($data['map_data'] ) {
			return view('Delivery_boy/track_order', $data);
		}else{
			return redirect()->to(base_url().'/Delivery_boy/dashboard');
		}
		
	}


}